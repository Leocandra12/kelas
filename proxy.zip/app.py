import asyncio
import os
import random
import tempfile
import time
from pathlib import Path

import aiohttp
from aiohttp_socks import ProxyConnector


# =========================================================
# PATH
# =========================================================

BASE_DIR = Path(__file__).resolve().parent

SOURCES_FILE = BASE_DIR / "sources.txt"

PROXY_FILE = BASE_DIR / "proxy.txt"
PROXIES_FILE = BASE_DIR / "proxies.txt"
ALIVE_FILE = BASE_DIR / "alive.txt"


# =========================================================
# SETTINGS
# =========================================================

REFRESH_INTERVAL = 30 * 60

CHECK_TIMEOUT = 8

# Jumlah proxy yang diperiksa bersamaan.
CONCURRENCY = 200

HTTP_CONNECTION_LIMIT = CONCURRENCY

HTTP_LIMIT_PER_HOST = 100

USER_AGENT = "PublicProxyHealthChecker/4.0"


# =========================================================
# PROXY LIMIT
# =========================================================

MAX_PROXIES = 6000

MAX_HTTP = 3000
MAX_SOCKS4 = 1500
MAX_SOCKS5 = 1500


# =========================================================
# SOURCE SETTINGS
# =========================================================

SOURCE_TIMEOUT = 25


# =========================================================
# RETRY
# =========================================================

RETRIES = 1

RETRY_DELAY = 0.25


# =========================================================
# FILE WRITE
# =========================================================

WRITE_INTERVAL = 1.0


# =========================================================
# MULTI URL TEST
# =========================================================

TEST_TARGETS = [

    {
        "name": "example",
        "url": "https://example.com/",
        "statuses": {200},
        "contains": b"Example Domain"
    },

    {
        "name": "httpbin",
        "url": "https://httpbin.org/get",
        "statuses": {200},
        "contains": b""
    },

    {
        "name": "cloudflare",
        "url": "https://www.cloudflare.com/cdn-cgi/trace",
        "statuses": {200},
        "contains": b""
    }

]


# =========================================================
# MINIMUM SUCCESS
# =========================================================

# 2 dari 3 target harus berhasil.
MIN_SUCCESS_TARGETS = 2


# =========================================================
# ATOMIC WRITE
# =========================================================

def atomic_write(path: Path, content: str):

    fd, temp_name = tempfile.mkstemp(
        prefix=f".{path.name}.",
        dir=path.parent
    )

    try:

        with os.fdopen(
            fd,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(content)
            f.flush()
            os.fsync(f.fileno())

        os.replace(
            temp_name,
            path
        )

    except Exception:

        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass

        raise


# =========================================================
# PARSE PROXY
# =========================================================

def parse_proxy(line: str):

    line = line.strip()

    if not line:
        return None

    if line.startswith("#"):
        return None

    protocol = None

    # protocol|host:port
    if "|" in line:

        protocol, line = line.split(
            "|",
            1
        )

        protocol = protocol.strip().lower()

    line = line.strip()

    # protocol://host:port
    if "://" in line:

        scheme, address = line.split(
            "://",
            1
        )

        scheme = scheme.strip().lower()

        if protocol is None:
            protocol = scheme

        line = address.strip()

    if protocol == "https":
        protocol = "http"

    if protocol not in {
        "http",
        "socks4",
        "socks5"
    }:
        return None

    # IPv6:
    # [2001:db8::1]:8080

    if line.startswith("["):

        closing = line.find("]")

        if closing == -1:
            return None

        host = line[
            1:closing
        ]

        remainder = line[
            closing + 1:
        ]

        if not remainder.startswith(":"):
            return None

        port = remainder[1:]

    else:

        if ":" not in line:
            return None

        host, port = line.rsplit(
            ":",
            1
        )

    host = host.strip()
    port = port.strip()

    if not host:
        return None

    if not port.isdigit():
        return None

    port_number = int(port)

    if not 1 <= port_number <= 65535:
        return None

    if ":" in host:
        host = f"[{host}]"

    return (
        protocol,
        f"{host}:{port_number}"
    )


# =========================================================
# LOAD SOURCES
# =========================================================

def load_sources():

    sources = []

    if not SOURCES_FILE.exists():

        print(
            "[ERROR] sources.txt tidak ditemukan",
            flush=True
        )

        return sources

    with open(
        SOURCES_FILE,
        "r",
        encoding="utf-8",
        errors="ignore"
    ) as f:

        for line_number, raw_line in enumerate(
            f,
            start=1
        ):

            line = raw_line.strip()

            if not line:
                continue

            if line.startswith("#"):
                continue

            if "|" not in line:

                print(
                    f"[SKIP SOURCE] "
                    f"baris {line_number}: {line}",
                    flush=True
                )

                continue

            protocol, url = line.split(
                "|",
                1
            )

            protocol = protocol.strip().lower()
            url = url.strip()

            if protocol == "https":
                protocol = "http"

            if protocol not in {
                "http",
                "socks4",
                "socks5"
            }:

                print(
                    f"[SKIP SOURCE] "
                    f"protocol tidak dikenal: "
                    f"{protocol}",
                    flush=True
                )

                continue

            if not url.startswith(
                (
                    "http://",
                    "https://"
                )
            ):

                print(
                    f"[SKIP SOURCE] "
                    f"URL tidak valid: {url}",
                    flush=True
                )

                continue

            sources.append(
                (
                    protocol,
                    url
                )
            )

    print(
        f"[SOURCE] "
        f"{len(sources)} endpoint ditemukan",
        flush=True
    )

    return sources


# =========================================================
# FETCH SOURCE
# =========================================================

async def fetch_source(
    session,
    source_protocol,
    url
):

    proxies = set()

    try:

        async with session.get(
            url,
            timeout=aiohttp.ClientTimeout(
                total=SOURCE_TIMEOUT
            ),
            headers={
                "User-Agent": USER_AGENT,
                "Accept": "text/plain,text/*,*/*"
            },
            allow_redirects=True
        ) as response:

            if response.status != 200:

                print(
                    f"[SOURCE ERROR] "
                    f"{response.status} "
                    f"{source_protocol} "
                    f"{url}",
                    flush=True
                )

                return proxies

            text = await response.text(
                errors="ignore"
            )

            for line in text.splitlines():

                parsed = parse_proxy(line)

                if parsed is None:
                    continue

                _, proxy = parsed

                # Protocol dari sources.txt
                # tetap menjadi protocol utama.
                proxies.add(
                    (
                        source_protocol,
                        proxy
                    )
                )

            print(
                f"[SOURCE OK] "
                f"{source_protocol:<6} "
                f"{len(proxies):>5} "
                f"{url}",
                flush=True
            )

    except asyncio.TimeoutError:

        print(
            f"[SOURCE TIMEOUT] "
            f"{source_protocol} "
            f"{url}",
            flush=True
        )

    except Exception as e:

        print(
            f"[SOURCE FAILED] "
            f"{source_protocol} "
            f"{url} -> "
            f"{type(e).__name__}: {e}",
            flush=True
        )

    return proxies


# =========================================================
# COLLECT PROXIES
# =========================================================

async def collect_proxies():

    sources = load_sources()

    if not sources:
        return set()

    connector = aiohttp.TCPConnector(
        limit=50,
        limit_per_host=10,
        ttl_dns_cache=300
    )

    timeout = aiohttp.ClientTimeout(
        total=SOURCE_TIMEOUT
    )

    async with aiohttp.ClientSession(
        connector=connector,
        timeout=timeout,
        headers={
            "User-Agent": USER_AGENT
        }
    ) as session:

        tasks = [
            fetch_source(
                session,
                protocol,
                url
            )
            for protocol, url in sources
        ]

        results = await asyncio.gather(
            *tasks,
            return_exceptions=True
        )

    grouped = {
        "http": set(),
        "socks4": set(),
        "socks5": set()
    }

    for result in results:

        if not isinstance(
            result,
            set
        ):
            continue

        for protocol, proxy in result:

            if protocol in grouped:

                grouped[
                    protocol
                ].add(proxy)

    print(
        "\n[COLLECT] "
        f"HTTP={len(grouped['http'])} "
        f"SOCKS4={len(grouped['socks4'])} "
        f"SOCKS5={len(grouped['socks5'])}",
        flush=True
    )

    # =====================================================
    # SELECT
    # =====================================================

    selected = set()

    limits = {
        "http": MAX_HTTP,
        "socks4": MAX_SOCKS4,
        "socks5": MAX_SOCKS5
    }

    for protocol in (
        "http",
        "socks4",
        "socks5"
    ):

        items = list(
            grouped[protocol]
        )

        random.shuffle(items)

        selected.update(
            (
                protocol,
                proxy
            )
            for proxy in items[
                :limits[protocol]
            ]
        )

    # Safety limit.
    if len(selected) > MAX_PROXIES:

        selected = set(
            list(selected)[
                :MAX_PROXIES
            ]
        )

    counts = {
        "http": 0,
        "socks4": 0,
        "socks5": 0
    }

    for protocol, _ in selected:

        counts[
            protocol
        ] += 1

    print(
        "[SELECTED] "
        f"TOTAL={len(selected)} "
        f"HTTP={counts['http']} "
        f"SOCKS4={counts['socks4']} "
        f"SOCKS5={counts['socks5']}",
        flush=True
    )

    return selected


# =========================================================
# RESULT STORE
# =========================================================

class ResultStore:

    def __init__(self):

        self.alive = {}

        self.lock = asyncio.Lock()

        self.dirty = False

        self.last_write = 0.0

    async def add(
        self,
        protocol,
        proxy,
        latency,
        status,
        successes
    ):

        key = (
            protocol,
            proxy
        )

        async with self.lock:

            old = self.alive.get(key)

            if (
                old is None
                or latency < old["latency"]
            ):

                self.alive[key] = {
                    "latency": latency,
                    "status": status,
                    "successes": successes
                }

                self.dirty = True

    def generate_contents(self):

        # -------------------------------------------------
        # proxy.txt
        # proxies.txt
        # -------------------------------------------------

        addresses = sorted(
            {
                proxy
                for protocol, proxy
                in self.alive.keys()
            }
        )

        if addresses:

            proxy_content = (
                "\n".join(addresses)
                + "\n"
            )

        else:

            proxy_content = ""

        # -------------------------------------------------
        # alive.txt
        # -------------------------------------------------

        sorted_alive = sorted(
            self.alive.items(),
            key=lambda item: (
                -item[1]["successes"],
                item[1]["latency"],
                item[0][0],
                item[0][1]
            )
        )

        lines = []

        for (
            protocol,
            proxy
        ), data in sorted_alive:

            lines.append(
                f"{protocol}|"
                f"{proxy}|"
                f"{data['latency']:.0f}ms|"
                f"{data['successes']}/"
                f"{len(TEST_TARGETS)} targets|"
                f"HTTP {data['status']}"
            )

        if lines:

            alive_content = (
                "\n".join(lines)
                + "\n"
            )

        else:

            alive_content = ""

        return (
            proxy_content,
            alive_content
        )

    async def write_files(
        self,
        force=False
    ):

        async with self.lock:

            if not self.dirty and not force:
                return

            now = time.monotonic()

            if (
                not force
                and now - self.last_write
                < WRITE_INTERVAL
            ):
                return

            proxy_content, alive_content = (
                self.generate_contents()
            )

            self.dirty = False

            self.last_write = now

        atomic_write(
            PROXY_FILE,
            proxy_content
        )

        atomic_write(
            PROXIES_FILE,
            proxy_content
        )

        atomic_write(
            ALIVE_FILE,
            alive_content
        )


# =========================================================
# WRITER LOOP
# =========================================================

async def writer_loop(
    store,
    stop_event
):

    while not stop_event.is_set():

        try:

            await store.write_files()

        except Exception as e:

            print(
                f"[WRITE ERROR] "
                f"{type(e).__name__}: {e}",
                flush=True
            )

        try:

            await asyncio.wait_for(
                stop_event.wait(),
                timeout=WRITE_INTERVAL
            )

        except asyncio.TimeoutError:
            pass

    try:

        await store.write_files(
            force=True
        )

    except Exception as e:

        print(
            f"[FINAL WRITE ERROR] "
            f"{type(e).__name__}: {e}",
            flush=True
        )


# =========================================================
# VALIDATE TARGET
# =========================================================

async def validate_target(
    response,
    target
):

    if response.status not in target["statuses"]:

        return False

    body = await response.read()

    if not body:

        return False

    expected = target.get(
        "contains",
        b""
    )

    if expected:

        if expected.lower() not in body.lower():

            return False

    return True


# =========================================================
# HTTP REQUEST
# =========================================================

async def http_request_via_proxy(
    session,
    proxy,
    target,
    timeout
):

    proxy_url = (
        f"http://{proxy}"
    )

    started = time.perf_counter()

    try:

        async with session.get(
            target["url"],
            proxy=proxy_url,
            timeout=aiohttp.ClientTimeout(
                total=timeout
            ),
            headers={
                "User-Agent": USER_AGENT
            },
            allow_redirects=False
        ) as response:

            valid = await validate_target(
                response,
                target
            )

            latency = (
                time.perf_counter()
                - started
            ) * 1000

            return (
                valid,
                latency,
                response.status
            )

    except Exception:

        return (
            False,
            0,
            0
        )


# =========================================================
# CREATE SOCKS SESSION
# =========================================================

async def create_socks_session(
    protocol,
    proxy
):

    proxy_url = (
        f"{protocol}://{proxy}"
    )

    connector = ProxyConnector.from_url(
        proxy_url,
        rdns=True
    )

    session = aiohttp.ClientSession(
        connector=connector,
        timeout=aiohttp.ClientTimeout(
            total=CHECK_TIMEOUT
        ),
        headers={
            "User-Agent": USER_AGENT
        }
    )

    return session


# =========================================================
# SOCKS REQUEST
# =========================================================

async def socks_request(
    session,
    target,
    timeout
):

    started = time.perf_counter()

    try:

        async with session.get(
            target["url"],
            timeout=aiohttp.ClientTimeout(
                total=timeout
            ),
            allow_redirects=False
        ) as response:

            valid = await validate_target(
                response,
                target
            )

            latency = (
                time.perf_counter()
                - started
            ) * 1000

            return (
                valid,
                latency,
                response.status
            )

    except Exception:

        return (
            False,
            0,
            0
        )


# =========================================================
# CHECK ONE TARGET
# =========================================================

async def check_target(
    protocol,
    proxy,
    target,
    http_session,
    socks_session=None
):

    for attempt in range(
        RETRIES + 1
    ):

        if protocol == "http":

            result = await http_request_via_proxy(
                http_session,
                proxy,
                target,
                CHECK_TIMEOUT
            )

        elif protocol in {
            "socks4",
            "socks5"
        }:

            result = await socks_request(
                socks_session,
                target,
                CHECK_TIMEOUT
            )

        else:

            return (
                False,
                0,
                0
            )

        if result[0]:

            return result

        if attempt < RETRIES:

            await asyncio.sleep(
                RETRY_DELAY
            )

    return (
        False,
        0,
        0
    )


# =========================================================
# CHECK PROXY
# =========================================================
#
# 3 target dijalankan secara PARALEL.
#
# =========================================================

async def check_proxy(
    protocol,
    proxy,
    http_session
):

    socks_session = None

    try:

        # -------------------------------------------------
        # Satu SOCKS session untuk ketiga target.
        # -------------------------------------------------

        if protocol in {
            "socks4",
            "socks5"
        }:

            try:

                socks_session = await create_socks_session(
                    protocol,
                    proxy
                )

            except Exception:

                return (
                    False,
                    0,
                    0,
                    0,
                    []
                )

        # -------------------------------------------------
        # Semua target berjalan bersamaan.
        # -------------------------------------------------

        tasks = [
            check_target(
                protocol,
                proxy,
                target,
                http_session,
                socks_session
            )
            for target in TEST_TARGETS
        ]

        results = await asyncio.gather(
            *tasks,
            return_exceptions=True
        )

        successful_targets = 0

        latencies = []

        last_status = 0

        successful_names = []

        for target, result in zip(
            TEST_TARGETS,
            results
        ):

            if isinstance(
                result,
                Exception
            ):
                continue

            alive, latency, status = result

            if alive:

                successful_targets += 1

                latencies.append(
                    latency
                )

                last_status = status

                successful_names.append(
                    target["name"]
                )

            elif status:

                last_status = status

        # -------------------------------------------------
        # Minimal 2/3.
        # -------------------------------------------------

        if successful_targets < MIN_SUCCESS_TARGETS:

            return (
                False,
                0,
                last_status,
                successful_targets,
                successful_names
            )

        if latencies:

            average_latency = (
                sum(latencies)
                / len(latencies)
            )

        else:

            average_latency = 0

        return (
            True,
            average_latency,
            last_status,
            successful_targets,
            successful_names
        )

    finally:

        if socks_session is not None:

            try:

                await socks_session.close()

            except Exception:
                pass


# =========================================================
# SCAN WORKER
# =========================================================

async def scan_worker(
    queue,
    store,
    http_session,
    counters,
    counter_lock
):

    while True:

        item = await queue.get()

        try:

            # -------------------------------------------------
            # Sentinel untuk menghentikan worker.
            # -------------------------------------------------

            if item is None:

                return

            protocol, proxy = item

            result = await check_proxy(
                protocol,
                proxy,
                http_session
            )

            (
                alive,
                latency,
                status,
                successes,
                successful_names
            ) = result

            if alive:

                await store.add(
                    protocol,
                    proxy,
                    latency,
                    status,
                    successes
                )

                print(
                    f"[ALIVE] "
                    f"{protocol:<6} "
                    f"{proxy:<22} "
                    f"{latency:>7.0f} ms "
                    f"{successes}/"
                    f"{len(TEST_TARGETS)} "
                    f"{','.join(successful_names)}",
                    flush=True
                )

                async with counter_lock:

                    counters["alive"] += 1

        except asyncio.CancelledError:

            # Cancellation harus diteruskan.
            raise

        except Exception as e:

            print(
                f"[CHECK ERROR] "
                f"{item[0]}|{item[1]} -> "
                f"{type(e).__name__}: {e}",
                flush=True
            )

        else:

            # Hanya dianggap selesai jika proses
            # check_proxy selesai normal.
            async with counter_lock:

                counters["completed"] += 1

                completed = counters["completed"]
                total = counters["total"]
                alive_count = counters["alive"]

                if (
                    completed % 100 == 0
                    or completed == total
                ):

                    print(
                        f"[SCAN] "
                        f"{completed}/{total} "
                        f"| alive={alive_count}",
                        flush=True
                    )

        finally:

            # task_done() tepat satu kali untuk
            # setiap queue.get().
            queue.task_done()


# =========================================================
# SCAN
# =========================================================

async def scan_proxies(
    proxies
):

    store = ResultStore()

    stop_event = asyncio.Event()

    writer_task = asyncio.create_task(
        writer_loop(
            store,
            stop_event
        )
    )

    connector = aiohttp.TCPConnector(
        limit=HTTP_CONNECTION_LIMIT,
        limit_per_host=HTTP_LIMIT_PER_HOST,
        ttl_dns_cache=300,
        enable_cleanup_closed=True
    )

    timeout = aiohttp.ClientTimeout(
        total=CHECK_TIMEOUT
    )

    total = len(proxies)

    counters = {
        "total": total,
        "completed": 0,
        "alive": 0
    }

    counter_lock = asyncio.Lock()

    # -----------------------------------------------------
    # Bounded queue.
    #
    # Maksimal 2x concurrency item menunggu.
    # Ini mencegah queue menyimpan terlalu banyak item
    # sekaligus.
    # -----------------------------------------------------

    queue = asyncio.Queue(
        maxsize=CONCURRENCY * 2
    )

    workers = []

    try:

        # -------------------------------------------------
        # HTTP session dibuat TERLEBIH DAHULU.
        # -------------------------------------------------

        async with aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers={
                "User-Agent": USER_AGENT
            }
        ) as http_session:

            # -------------------------------------------------
            # Worker dibuat SEBELUM queue diisi.
            #
            # Ini penting karena queue memiliki maxsize.
            # -------------------------------------------------

            worker_count = min(
                CONCURRENCY,
                total
            )

            for _ in range(
                worker_count
            ):

                workers.append(
                    asyncio.create_task(
                        scan_worker(
                            queue,
                            store,
                            http_session,
                            counters,
                            counter_lock
                        )
                    )
                )

            print(
                f"[WORKER] "
                f"{worker_count} worker HTTP aktif",
                flush=True
            )

            # -------------------------------------------------
            # Sekarang masukkan proxy.
            #
            # Jika queue penuh, await queue.put()
            # akan menunggu sampai worker mengambil item.
            # Tidak terjadi deadlock karena worker sudah aktif.
            # -------------------------------------------------

            for item in proxies:

                await queue.put(
                    item
                )

            print(
                f"[QUEUE] "
                f"{total} proxy masuk queue",
                flush=True
            )

            # -------------------------------------------------
            # Tunggu seluruh proxy selesai.
            # -------------------------------------------------

            await queue.join()

            # -------------------------------------------------
            # Semua proxy selesai.
            # Sekarang kirim sentinel ke worker.
            # -------------------------------------------------

            for _ in workers:

                await queue.put(
                    None
                )

            # -------------------------------------------------
            # Tunggu semua worker berhenti.
            # -------------------------------------------------

            await asyncio.gather(
                *workers,
                return_exceptions=True
            )

            workers = []

            # -------------------------------------------------
            # Final write.
            # -------------------------------------------------

            await store.write_files(
                force=True
            )

            print(
                "\n[SCAN DONE] "
                f"checked={counters['completed']} "
                f"alive={counters['alive']}",
                flush=True
            )

            counts = {
                "http": 0,
                "socks4": 0,
                "socks5": 0
            }

            for protocol, proxy in store.alive.keys():

                if protocol in counts:

                    counts[
                        protocol
                    ] += 1

            print(
                "[ALIVE] "
                f"HTTP={counts['http']} "
                f"SOCKS4={counts['socks4']} "
                f"SOCKS5={counts['socks5']}",
                flush=True
            )

    finally:

        # -----------------------------------------------------
        # Bersihkan worker jika terjadi error.
        # -----------------------------------------------------

        for worker in workers:

            if not worker.done():

                worker.cancel()

        if workers:

            await asyncio.gather(
                *workers,
                return_exceptions=True
            )

        stop_event.set()

        try:

            await writer_task

        except Exception:
            pass


# =========================================================
# CLEAR RESULTS
# =========================================================

async def clear_results():

    atomic_write(
        PROXY_FILE,
        ""
    )

    atomic_write(
        PROXIES_FILE,
        ""
    )

    atomic_write(
        ALIVE_FILE,
        ""
    )

    print(
        "[CLEAR] Hasil scan sebelumnya dihapus",
        flush=True
    )


# =========================================================
# ONE SCAN
# =========================================================

async def scan_once():

    print(
        "\n" + "=" * 70,
        flush=True
    )

    print(
        "[START] Multi-URL parallel scan baru",
        flush=True
    )

    print(
        "=" * 70,
        flush=True
    )

    print(
        "[TEST] Target:",
        flush=True
    )

    for target in TEST_TARGETS:

        print(
            f"       - {target['name']}: "
            f"{target['url']}",
            flush=True
        )

    print(
        f"[TEST] Minimum sukses: "
        f"{MIN_SUCCESS_TARGETS}/"
        f"{len(TEST_TARGETS)}",
        flush=True
    )

    await clear_results()

    proxies = await collect_proxies()

    if not proxies:

        print(
            "[STOP] Tidak ada proxy",
            flush=True
        )

        return

    await scan_proxies(
        proxies
    )


# =========================================================
# MAIN
# =========================================================

async def main():

    print(
        "[START] Multi-URL Parallel Proxy Aggregator",
        flush=True
    )

    print(
        f"[INFO] Max proxy/scan : {MAX_PROXIES}",
        flush=True
    )

    print(
        f"[INFO] HTTP           : {MAX_HTTP}",
        flush=True
    )

    print(
        f"[INFO] SOCKS4         : {MAX_SOCKS4}",
        flush=True
    )

    print(
        f"[INFO] SOCKS5         : {MAX_SOCKS5}",
        flush=True
    )

    print(
        f"[INFO] Concurrency    : {CONCURRENCY}",
        flush=True
    )

    print(
        f"[INFO] Timeout        : {CHECK_TIMEOUT}s",
        flush=True
    )

    print(
        f"[INFO] Retry          : {RETRIES}",
        flush=True
    )

    print(
        f"[INFO] Targets        : "
        f"{len(TEST_TARGETS)}",
        flush=True
    )

    print(
        f"[INFO] Required       : "
        f"{MIN_SUCCESS_TARGETS}/"
        f"{len(TEST_TARGETS)}",
        flush=True
    )

    print(
        "[INFO] Target mode    : PARALLEL",
        flush=True
    )

    print(
        "[INFO] Worker mode    : QUEUE",
        flush=True
    )

    print(
        f"[INFO] Queue max      : "
        f"{CONCURRENCY * 2}",
        flush=True
    )

    print(
        f"[INFO] Refresh        : "
        f"{REFRESH_INTERVAL // 60} menit",
        flush=True
    )

    while True:

        started = time.monotonic()

        try:

            await scan_once()

        except Exception as e:

            print(
                f"[MAIN ERROR] "
                f"{type(e).__name__}: {e}",
                flush=True
            )

        elapsed = (
            time.monotonic()
            - started
        )

        print(
            f"\n[SCAN TIME] "
            f"{elapsed:.1f} detik",
            flush=True
        )

        print(
            "[SLEEP] Menunggu "
            f"{REFRESH_INTERVAL // 60} menit...",
            flush=True
        )

        await asyncio.sleep(
            REFRESH_INTERVAL
        )


# =========================================================
# RUN
# =========================================================

if __name__ == "__main__":

    try:

        asyncio.run(
            main()
        )

    except KeyboardInterrupt:

        print(
            "\n[STOP] Program dihentikan",
            flush=True
        )